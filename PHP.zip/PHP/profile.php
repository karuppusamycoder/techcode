<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "interview";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $dob = $_POST["dob"];
    $age = $_POST["age"];

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO user (name, email, phone, dob, age) VALUES (:name, :email, :phone, :dob, :age)");

    // Bind parameters
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':dob', $dob);
    $stmt->bindParam(':age', $age);

    // Execute statement
    $stmt->execute();

    echo "User profile updated successfully";
}
catch(PDOException $e) {
    echo "Error updating user profile: " . $e->getMessage();
}

// Close connection
$conn = null;
?>