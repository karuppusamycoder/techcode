<?php

$host = 'localhost';
$dbname = 'interview';
$user = 'root';
$password = '';

try {
  $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
  die("Connection failed: " . $e->getMessage());
}

// Check if email and password are set
if (isset($_POST['email']) && isset($_POST['password'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];

  // Prepare SQL statement
  $stmt = $conn->prepare("SELECT * FROM information WHERE email=? AND password=?");
  $stmt->execute([$email, $password]);
  $result = $stmt->fetch(PDO::FETCH_ASSOC);

  // Check if there's a matching row in the table
  if ($result) {
    echo 'success';
  } else {
    echo 'error';
  }

  // Close prepared statement and database connection
  $stmt = null;
  $conn = null;
}
?>
