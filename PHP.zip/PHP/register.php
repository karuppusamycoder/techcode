<?php

$host = 'localhost';
$dbname = 'interview';
$user = 'root';
$password = '';

try {
  $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
  die("Connection failed: " . $e->getMessage());
}

$email = $_POST['email'];
$password = $_POST['psw'];


$stmt = $conn->prepare("SELECT * FROM information WHERE email = ?");
$stmt->execute([$email]);

if ($stmt->rowCount() > 0) {
  
  echo "Email already exists in the table";
} else {
  
  $stmt = $conn->prepare("INSERT INTO information (email, password) VALUES (?, ?)");
  $stmt->execute([$email, $password]);

  if ($stmt->rowCount() > 0) {
    
    echo "Form submitted successfully";
  } else {
    
    echo "Error submitting form";
  }
}

$conn = null;
?>