const validateForm = () => {
  const email = $('#email').val();
  const password = $('#psw').val();
  const repeatPassword = $('#psw-repeat').val();

  if (email === '' || password === '' || repeatPassword === '') {
    alert('Please fill in all the fields');
    return;
  }

  if (password !== repeatPassword) {
    alert('Passwords do not match');
    return;
  }

  
  $.ajax({
    type: 'POST',
    url: 'PHP/register.php',
    data: $('#register-form').serialize(),
    success: (response) => {
     
      $('.modal').hide();
      
      alert('Form submitted successfully');
      window.location.href = 'login.html';
      exit();
    },
    error: (xhr, status, error) => {
      if (error.includes('Email already exists')) {
        alert('Email already exists. Please use a different email.');
      } else {
        alert('Error submitting form');
      }
    }
  });
};