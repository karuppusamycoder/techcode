$(document).ready(function() {
  $('form').submit(function(e) {
    e.preventDefault();
    $.ajax({
      type: 'POST',
      url: 'PHP/profile.php',
      data: $('form').serialize(),
      success: function(response) {
        alert(response);
        location.reload();
      },
      error: function(xhr, status, error) {
        alert("Error: " + error);
      }
    });
  });
});