$(document).ready(function() {
  $('#login-form').submit(function(event) {
    event.preventDefault(); // Prevent default form submission behavior
    
    // Get form data
    var email = $('#email').val();
    var password = $('#password').val();
    
    // Send AJAX request to server
    $.ajax({
      type: 'POST',
      url: 'PHP/login.php',
      data: {email: email, password: password},
      success: function(response) {
        if (response === 'success') {
          window.location.href = 'profile.html'; // Redirect to profile page
        } else {
          alert('Invalid email or password!'); // Show error message
        }
      },
      error: function() {
        alert('Error occurred while processing your request!'); // Show error message
      }
    });
  });
});